
public class Aya2 {

	public Aya2() {
		super();
		
	}
	
public static int power(int a, int b) {
	int c=a;
	for (int i=1;i<b;i++) {
		a=a*c;
	}
	return a;
}
public static int power3(int a, int b) {
	if(b==0)
		return 1;
	else if(b%2==0) {
		int result=power3(a,(int)b/2);
		return result*result;
	}else {
		int result=power3(a,(int)((b-1)/2));
		return result*result*a;
	}
		
	
}
public static void mergesortDC(int[]a, int l, int h) {
	if(l<h) {
		int mid=(int)((l+h)/2);
		mergesortDC(a,l,mid);
		mergesortDC(a,mid+1,h);
		merge(a,l,mid,h);
		
	}
}
public static void merge(int[] arr, int low, int mid, int high) {
    int n1 = mid - low + 1;
    int n2 = high - mid;
    int[] left = new int[n1];
    int[] right = new int[n2];

    for (int i = 0; i < n1; i++) {
        left[i] = arr[low + i];
    }
    for (int i = 0; i < n2; i++) {
        right[i] = arr[mid + 1 + i];
    }

    int i = 0, j = 0, k = low;

    while (i < n1 && j < n2) {
        if (left[i] <= right[j]) {
            arr[k] = left[i];
            i++;
        } else {
            arr[k] = right[j];
            j++;
        }
        k++;
    }

    while (i < n1) {
        arr[k] = left[i];
        i++;
        k++;
    }

    while (j < n2) {
        arr[k] = right[j];
        j++;
        k++;
    }
}
public static boolean binarys(int[] a, int x, int l, int h) {
    if (l <= h) {
        int mid = (l + h) / 2;
        if (a[mid] == x) {
            return true;
        } else if (a[mid] < x) {
            return binarys(a, x, mid + 1, h);
        } else {
            return binarys(a, x, l, mid - 1);
        }
    }
    return false;
}
public static void pairs(int[] a, int x) {
	mergesortDC(a, 0, a.length-1);

    for (int i = 0; i < a.length; i++) {
        int result = x - a[i];
        if (binarys(a, x, i + 1, a.length - 1)) {
            System.out.println(a[i] + " + " + result + " = " + x);
        }
    }
}

public static void main (String [] args) {
	
	int[] S = {1,2,3,4,5,9};
    int x = 5;
    
    long[] y= new long[9999999];
        for (int i = 1; i <= 100000; i*=2) {
        
        long startTime = System.nanoTime();
        power3(2,7);
        long endTime = System.nanoTime();
        long elapsedTime = endTime - startTime;
        y[i]= elapsedTime;
       // System.out.println("n = " + i + ", Time = " + elapsedTime + " ms");
    }
  
    int[]aa=new int[99999999];
    long[] a = new long[99999999];
    for (int i = 1; i <= 100000; i*=2) {
        aa[i]=i;
        long startTime = System.nanoTime();
        pairs(S, x);
        long endTime = System.nanoTime();
        long elapsedTime = (endTime - startTime)/1000000;
        a[i]= elapsedTime;
       // System.out.println("n = " + i + ", Time = " + elapsedTime + " ms");
    }
    
  
}
}
	





